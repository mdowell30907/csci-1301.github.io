using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Welcome_Sol")]
[assembly: AssemblyCompany("Augusta University")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
