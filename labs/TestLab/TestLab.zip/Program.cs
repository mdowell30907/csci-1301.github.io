using System;

class Program
{
    static void Main()
    {
       int x = 5, y = 4;
       Console.WriteLine(x + y);
    }
}
